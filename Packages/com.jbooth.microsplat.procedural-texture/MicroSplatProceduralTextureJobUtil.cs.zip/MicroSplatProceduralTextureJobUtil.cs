﻿using UnityEngine;
using System.Collections;

using Unity.Collections;
using Unity.Mathematics;

namespace JBooth.MicroSplat
{
    public class MicroSplatProceduralTextureJobUtil
    {
        public struct TextureData8
        {
            public NativeArray<Color32> texture;
            public int width;
            public int height;
        }
        public struct TextureData16
        {
            public NativeArray<half4> texture;
            public int width;
            public int height;
        }


        static Color BilinearSample(TextureData8 tex, Vector2 uv)
        {
            uv.x = Mathf.Repeat(uv.x, 1.0f);
            uv.y = Mathf.Repeat(uv.y, 1.0f);

            float u = uv.x * tex.width - 0.5f;
            float v = uv.y * tex.height - 0.5f;

            int x = (int)u;
            int y = (int)v;
            float u_ratio = u - x;
            float v_ratio = v - y;


            int x1 = x + 1;
            int y1 = y + 1;

            if (x1 >= tex.width)
            {
                x1 -= tex.width;
            }
            if (y1 >= tex.height)
            {
                y1 -= tex.height;
            }


            Color h0 = tex.texture[y * tex.width + x];
            Color h1 = tex.texture[y * tex.width + x1];
            Color h2 = tex.texture[y1 * tex.width + x];
            Color h3 = tex.texture[y1 * tex.width + x1];

            float u_opposite = 1.0f - u_ratio;
            float v_opposite = 1.0f - v_ratio;

            Color result;
            result.r = (h0.r * u_opposite + h1.r * u_ratio) * v_opposite + (h2.r * u_opposite + h3.r * u_ratio) * v_ratio;
            result.g = (h0.g * u_opposite + h1.g * u_ratio) * v_opposite + (h2.g * u_opposite + h3.g * u_ratio) * v_ratio;
            result.b = (h0.b * u_opposite + h1.b * u_ratio) * v_opposite + (h2.b * u_opposite + h3.b * u_ratio) * v_ratio;
            result.a = (h0.a * u_opposite + h1.a * u_ratio) * v_opposite + (h2.a * u_opposite + h3.a * u_ratio) * v_ratio;
            return result;

        }

        static Color BilinearSample(TextureData16 tex, Vector2 uv)
        {
            uv.x = Mathf.Repeat(uv.x, 1.0f);
            uv.y = Mathf.Repeat(uv.y, 1.0f);

            float u = uv.x * tex.width - 0.5f;
            float v = uv.y * tex.height - 0.5f;

            int x = (int)u;
            int y = (int)v;
            float u_ratio = u - x;
            float v_ratio = v - y;


            int x1 = x + 1;
            int y1 = y + 1;

            if (x1 >= tex.width)
            {
                x1 -= tex.width;
            }
            if (y1 >= tex.height)
            {
                y1 -= tex.height;
            }


            half4 h0 = tex.texture[y * tex.width + x];
            half4 h1 = tex.texture[y * tex.width + x1];
            half4 h2 = tex.texture[y1 * tex.width + x];
            half4 h3 = tex.texture[y1 * tex.width + x1];

            float u_opposite = 1.0f - u_ratio;
            float v_opposite = 1.0f - v_ratio;

            Color result;
            result.r = (h0.x * u_opposite + h1.x * u_ratio) * v_opposite + (h2.x * u_opposite + h3.x * u_ratio) * v_ratio;
            result.g = (h0.y * u_opposite + h1.y * u_ratio) * v_opposite + (h2.y * u_opposite + h3.y * u_ratio) * v_ratio;
            result.b = (h0.z * u_opposite + h1.z * u_ratio) * v_opposite + (h2.z * u_opposite + h3.z * u_ratio) * v_ratio;
            result.a = (h0.w * u_opposite + h1.w * u_ratio) * v_opposite + (h2.w * u_opposite + h3.w * u_ratio) * v_ratio;
            return result;

        }

        public enum NoiseUVMode
        {
            UV = 0,
            World,
            Triplanar
        }

        static float PCFilter(int index, float height, float slope, float3 worldPos, float2 uv, 
            Color bMask, out int texIndex, half3 pN, 
            TextureData8 procTexCurves, TextureData16 procTexParams, TextureData8 procTexNoise, NoiseUVMode noiseMode)
        {
            // params0 are rgba (noise scale, min, max, offset)
            // params1 are rg (weight, index)
            float2 noiseUV = uv;

            float offset = 1.0f / 32.0f;
            float halfOff = 1.0f / 64.0f;
            float y = (index * offset) + halfOff;

            half h0 = BilinearSample(procTexCurves, new float2(height, y)).r;
            half s0 = BilinearSample(procTexCurves, new float2(slope, y)).g;
            Color params0 = BilinearSample(procTexParams, new float2(0.166666f, y));
            Color params1 = BilinearSample(procTexParams, new float2(0.5f, y));
            Color params2 = BilinearSample(procTexParams, new float2(0.833333f, y));



            // WOW, this is odd. So if we do triplanar or world space, the actual UVs which are set on the config.uv end up 0
            // However, if we use those UVs to sample a texture and then multiply the saturate(result+1) (which is basically always 1)
            // into the noise it works around the bug- which must be something in the compiler.

            Color noise = new Color(0, 0, 0, 0);
            if (noiseMode == NoiseUVMode.Triplanar)
            {
                Color noise0 = BilinearSample(procTexNoise, new float2(worldPos.zy * 0.002f * params0.r + params0.a));
                Color noise1 = BilinearSample(procTexNoise, new float2(worldPos.xz * 0.002f * params0.r + params0.a + 0.31f));
                Color noise2 = BilinearSample(procTexNoise, new float2(worldPos.xy * 0.002f * params0.r + params0.a + 0.71f));
                noise = noise0 * pN.x + noise1 * pN.y + noise2 * pN.z;
            }
            else if (noiseMode == NoiseUVMode.World)
            {
                noise = BilinearSample(procTexNoise, new float2(noiseUV * params0.r + params0.a));
            }
            else if (noiseMode == NoiseUVMode.UV)
            {
                noise *= BilinearSample(procTexNoise, new float2(worldPos.xz * 0.002f * params0.r + params0.a));
            }

            // unpack
            noise.r = noise.r * 2 - 1;
            noise.g = noise.g * 2 - 1;

            h0 *= 1.0f + math.lerp(params0.g, params0.b, noise.r);
            s0 *= 1.0f + math.lerp(params0.g, params0.b, noise.g);

            half bWeight = 1;
            bMask *= params2;
            bWeight = math.max(math.max(math.max(bMask.r, bMask.g), bMask.b), bMask.a);

            texIndex = (int)params1.g;
            return math.saturate(h0 * s0 * params1.r * bWeight);
        }

        static void PCProcessLayer(ref half4 weights, ref int4 indexes, ref float totalWeight, 
            int curIdx, float height, float slope, float3 worldPos, float2 uv, 
            Color biomeMask, half3 pN,
            TextureData8 procTexCurves, TextureData16 procTexParams, TextureData8 procTexNoise, NoiseUVMode noiseMode)
        {
            int texIndex = 0;
            half w = PCFilter(curIdx, height, slope, worldPos, uv, biomeMask, out texIndex, pN, procTexCurves, procTexParams, procTexNoise, noiseMode);
            w = math.min(totalWeight, w);
            totalWeight -= w;

            // sort
            if (w > weights.x)
            {
                weights.w = weights.z;
                weights.z = weights.y;
                weights.y = weights.x;
                indexes.w = indexes.z;
                indexes.z = indexes.y;
                indexes.y = indexes.x;
                weights.x = w;
                indexes.x = texIndex;
            }
            else if (w > weights.y)
            {
                weights.w = weights.z;
                weights.z = weights.y;
                indexes.w = indexes.z;
                indexes.z = indexes.y;
                weights.y = w;
                indexes.y = texIndex;
            }
            else if (w > weights.z)
            {
                weights.w = weights.z;
                indexes.w = indexes.z;
                weights.z = w;
                indexes.z = texIndex;
            }
            else if (w > weights.w)
            {
                weights.w = w;
                indexes.w = texIndex;
            }
        }


        public static void SampleJob(float2 uv, float3 worldPos, int layerCount, float worldHeight, float2 worldRange, float3 worldNormal, float3 up,
        TextureData8 curves, TextureData16 properties, TextureData8 noise, TextureData8 mask, bool useBiomMask, NoiseUVMode noiseUVMode, out half4 weights, out int4 indexes)
        {

            weights = new half4(0, 0, 0, 0);

            float height = math.saturate((worldHeight - worldRange.x) / math.max(0.1f, (worldRange.y - worldRange.x)));
            float slope = 1.0f - math.saturate(math.dot(worldNormal, up) * 0.5f + 0.49f);

            // find 4 highest weights and indexes
            indexes = new int4(0, 1, 2, 3);
            float totalWeight = 1.0f;

            Color biomeMask = new Color(1, 1, 1, 1);
            if (useBiomMask)
            {
                biomeMask = BilinearSample(mask, uv);
            }

            half3 pN = new half3(0,0,0);
            if (noiseUVMode == NoiseUVMode.Triplanar)
            {
                pN = math.pow(math.abs(worldNormal), 4);
                float ttl = pN.x + pN.y + pN.z;
                pN.x /= ttl;
                pN.y /= ttl;
                pN.z /= ttl;
            }


            for (int i = 0; i < layerCount; ++i)
            {
                PCProcessLayer(ref weights, ref indexes, ref totalWeight, i, height, slope, worldPos, uv, biomeMask, pN, curves, properties, noise, noiseUVMode);
            }

        }
    }
}

